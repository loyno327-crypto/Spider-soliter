# Паук — пасьянс → Android APK

Готовая упаковка исходного `spider-1.html` в Android-приложение через Capacitor.

## Самый простой способ получить APK

1. Создайте пустой репозиторий на GitHub.
2. Загрузите в репозиторий содержимое этого проекта.
3. Откройте **Actions** → **Build Android APK**.
4. Нажмите **Run workflow** → выберите `main` → **Run workflow**.
5. Дождитесь зелёной галочки.
6. Откройте запуск workflow и найдите раздел **Artifacts**.
7. Скачайте `spider-solitaire-debug-apk`.
8. Распакуйте ZIP — внутри будет `app-debug.apk`.
9. Передайте APK на Android-телефон и установите его.

Каждый push в `main` также автоматически запускает сборку.

## Что находится внутри

- `www/index.html` — исходная игра.
- `capacitor.config.json` — имя приложения и Android package ID.
- `package.json` — зависимости Capacitor 8.
- `.github/workflows/build-apk.yml` — автоматическая сборка APK на GitHub.

## Изменение package ID

Сейчас используется `com.example.spidersolitaire`. Для публикации своего приложения лучше заменить его на уникальный идентификатор, например `com.yourname.spidersolitaire`, в `capacitor.config.json`.

## Debug и Google Play

Workflow собирает debug APK для установки и проверки. Для Google Play нужен release APK/AAB с подписью приложения и отдельными секретами GitHub.
